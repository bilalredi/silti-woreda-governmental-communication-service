/* ==========================================================================
   Silti Woreda Communication Office — Gallery Lightbox & Slider
   ========================================================================== */
(function () {
  "use strict";

  document.addEventListener("DOMContentLoaded", function () {
    initLightbox();
    initNoticeSlider();
  });

  /* ---------------- Gallery lightbox ---------------- */
  function initLightbox() {
    var items = document.querySelectorAll(".gallery-item");
    var lightbox = document.querySelector("#lightbox");
    if (!items.length || !lightbox) return;

    var lightboxCaption = lightbox.querySelector(".lightbox-caption");
    var lightboxPanel = lightbox.querySelector(".lightbox-panel");
    var closeBtn = lightbox.querySelector(".lightbox-close");
    var prevBtn = lightbox.querySelector(".lightbox-prev");
    var nextBtn = lightbox.querySelector(".lightbox-next");
    var currentIndex = 0;
    var itemsArr = Array.prototype.slice.call(items);

    function openAt(index) {
      currentIndex = (index + itemsArr.length) % itemsArr.length;
      var el = itemsArr[currentIndex];
      var caption = el.getAttribute("data-caption") || el.querySelector("span") && el.querySelector("span").textContent || "";
      lightboxCaption.textContent = caption;
      lightboxPanel.style.background = window.getComputedStyle(el).backgroundImage !== "none"
        ? window.getComputedStyle(el).backgroundImage
        : window.getComputedStyle(el).background;
      lightbox.classList.add("is-open");
      lightbox.setAttribute("aria-hidden", "false");
      closeBtn.focus();
    }
    function close() {
      lightbox.classList.remove("is-open");
      lightbox.setAttribute("aria-hidden", "true");
    }

    itemsArr.forEach(function (el, index) {
      var trigger = el.querySelector(".gallery-lightbox-btn") || el;
      trigger.addEventListener("click", function (e) {
        e.preventDefault();
        openAt(index);
      });
    });

    if (closeBtn) closeBtn.addEventListener("click", close);
    if (prevBtn) prevBtn.addEventListener("click", function () { openAt(currentIndex - 1); });
    if (nextBtn) nextBtn.addEventListener("click", function () { openAt(currentIndex + 1); });
    lightbox.addEventListener("click", function (e) {
      if (e.target === lightbox) close();
    });
    document.addEventListener("keydown", function (e) {
      if (!lightbox.classList.contains("is-open")) return;
      if (e.key === "Escape") close();
      if (e.key === "ArrowRight") openAt(currentIndex + 1);
      if (e.key === "ArrowLeft") openAt(currentIndex - 1);
    });
  }

  /* ---------------- Public notices auto-rotating slider ---------------- */
  function initNoticeSlider() {
    var track = document.querySelector(".ticker-track ul");
    if (!track) return;
    // Duplicate ticker items once so the CSS marquee (translateX -50%) loops seamlessly.
    var clone = track.innerHTML;
    track.innerHTML = clone + clone;
  }
})();
