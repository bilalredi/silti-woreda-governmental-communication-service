/* ==========================================================================
   Silti Woreda Communication Office — Site Search
   A lightweight, dependency-free client-side search over a static index
   of the site's pages, services, news, and publications.
   ========================================================================== */
(function () {
  "use strict";

  var SEARCH_INDEX = [
    { title: "About the Office", url: "about.html", category: "Page", desc: "Our mandate, history, leadership and organizational structure." },
    { title: "Vision, Mission & Values", url: "about.html#vmv", category: "Page", desc: "What guides Silti Woreda Communication in serving the public." },
    { title: "Government Services", url: "services.html", category: "Page", desc: "Public information requests, press accreditation, and media support." },
    { title: "News & Announcements", url: "news.html", category: "Page", desc: "Latest updates and public notices from the Woreda administration." },
    { title: "Press Releases", url: "news.html#press-releases", category: "Page", desc: "Official statements issued by the communication office." },
    { title: "Research & Publications", url: "publications.html", category: "Page", desc: "Studies, bulletins, and downloadable public documents." },
    { title: "Media Gallery", url: "gallery.html", category: "Page", desc: "Photos and videos from public events and programs." },
    { title: "Downloads", url: "publications.html#downloads", category: "Page", desc: "Forms, reports, and official documents available for download." },
    { title: "Contact & Directions", url: "contact.html", category: "Page", desc: "Office location, phone, WhatsApp, and inquiry form." },
    { title: "Public Information Request", url: "services.html#info-request", category: "Service", desc: "Submit a formal request for public information." },
    { title: "Press Accreditation", url: "services.html#accreditation", category: "Service", desc: "Apply for media accreditation to cover Woreda events." },
    { title: "Media & Interview Requests", url: "services.html#media-requests", category: "Service", desc: "Coordinate interviews and statements with office spokespersons." },
    { title: "Public Complaint & Feedback", url: "services.html#feedback", category: "Service", desc: "Share feedback or concerns about government communication." },
    { title: "Event & Program Coverage", url: "services.html#coverage", category: "Service", desc: "Request communication support for a public program or event." },
    { title: "Content & Translation Support", url: "services.html#translation", category: "Service", desc: "Request translation of public materials into local languages." }
  ];

  document.addEventListener("DOMContentLoaded", function () {
    var form = document.querySelector("#site-search-form");
    var input = document.querySelector("#site-search-input");
    var results = document.querySelector("#search-results");
    if (!form || !input || !results) return;

    var debounceTimer;
    input.addEventListener("input", function () {
      clearTimeout(debounceTimer);
      debounceTimer = setTimeout(function () { runSearch(input.value); }, 150);
    });

    form.addEventListener("submit", function (e) {
      e.preventDefault();
      runSearch(input.value);
    });

    function runSearch(rawQuery) {
      var query = rawQuery.trim().toLowerCase();
      results.innerHTML = "";
      if (query.length < 2) return;

      var matches = SEARCH_INDEX.filter(function (item) {
        var haystack = (item.title + " " + item.desc + " " + item.category).toLowerCase();
        return haystack.indexOf(query) !== -1;
      });

      if (matches.length === 0) {
        var empty = document.createElement("p");
        empty.className = "no-results";
        empty.textContent = "No results for \u201c" + rawQuery.trim() + "\u201d. Try a different term, or browse the main menu.";
        results.appendChild(empty);
        return;
      }

      matches.slice(0, 8).forEach(function (item) {
        var link = document.createElement("a");
        link.href = item.url;
        link.innerHTML = escapeHtml(item.title) +
          "<small>" + escapeHtml(item.category) + " \u2014 " + escapeHtml(item.desc) + "</small>";
        results.appendChild(link);
      });
    }

    function escapeHtml(str) {
      var div = document.createElement("div");
      div.textContent = str;
      return div.innerHTML;
    }
  });
})();
