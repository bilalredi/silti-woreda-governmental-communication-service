# Silti Woreda Communication — Official Website

A responsive, accessible static website for the **Silti Woreda Communication Office** (Silti Woreda, Ethiopia). Built with clean HTML5, CSS3, and vanilla JavaScript — no build step, no framework, no server required.

## Contents

```
silti-woreda-communication/
│
├── index.html          Homepage
├── about.html           About, vision/mission/values, timeline, teams
├── services.html        Government services (6 detailed service sections)
├── news.html             News, press releases, public notices (filterable)
├── publications.html    Research highlights + downloads table
├── gallery.html          Media gallery with lightbox
├── contact.html          Contact form, office details, map placeholder
│
├── css/
│   ├── style.css         Design tokens, base styles, components
│   ├── responsive.css    Breakpoints (1024 / 900 / 720 / 520px)
│   └── animation.css     Keyframes, scroll-reveal, motion (respects prefers-reduced-motion)
│
├── js/
│   ├── script.js         Mobile nav, search panel, scroll reveal, stat counters, back-to-top
│   ├── search.js         Client-side site search (static index)
│   └── slider.js         Gallery lightbox + ticker loop
│
├── images/                Reserved for photography (currently uses inline SVG placeholders)
├── assets/
│   ├── icons/favicon.svg  Site emblem / favicon
│   └── fonts/             Reserved for self-hosted fonts if needed
│
└── README.md
```

## Design

- **Palette:** deep blue (`#0A3D5C`), teal (`#0F7173`), green (`#1E7A4C`), gold accent (`#C9962C`), off-white background — a professional government identity with a restrained nod to Ethiopian visual language.
- **Type:** Source Serif 4 for headings, IBM Plex Sans for body/UI, IBM Plex Mono for data, dates, and labels. Loaded via Google Fonts in each page `<head>`.
- **Signature element:** the gold-and-green "woven strip" divider above the footer, referencing traditional Silte weaving patterns as an official letterhead motif.
- All photography is currently represented with styled placeholder blocks and inline SVG — drop real photos into `/images` and swap the relevant `background`/`<img>` references before launch.

## Accessibility

- Skip-to-content link, semantic landmarks (`header`, `nav`, `main`, `footer`)
- Visible focus states (`:focus-visible`)
- `aria-current`, `aria-expanded`, `aria-pressed`, `aria-hidden` used throughout interactive components
- Reduced-motion support via `prefers-reduced-motion`
- Color contrast checked against WCAG AA for text on all backgrounds

## SEO

- Unique `<title>` and meta description per page
- Canonical URLs, Open Graph tags on the homepage
- Semantic heading hierarchy
- `schema.org` GovernmentOffice structured data on the homepage
- Fast-loading: no build tooling, no heavy frameworks, SVG instead of icon fonts

## Editing content

This is a static multi-page site — each `.html` file is self-contained (no templating engine), so shared sections (header, footer, search panel) are repeated across pages. To update site-wide content such as the phone number, office address, or navigation links, use find-and-replace across all `.html` files, or migrate to a static site generator / CMS if the site grows beyond seven pages.

Key contact details currently hard-coded across the site:
- Phone / WhatsApp: **+251 972 625 665**
- Location: **Silti Woreda, Silte Zone, Ethiopia**

The `js/search.js` file contains a small static search index (`SEARCH_INDEX`) — update this array whenever pages, services, or anchors change.

## Deployment

This site is plain static HTML/CSS/JS and can be deployed to any static host:

1. **GitHub Pages** — push this folder to a repository and enable Pages on the `main` branch.
2. **Netlify / Vercel** — drag-and-drop the folder, or connect the repository (no build command needed).
3. **Traditional web hosting** — upload the contents via FTP/SFTP to the public web root.

Before going live:
- Replace the Google Maps placeholder in `index.html` / `contact.html` with a real embedded map (`<iframe>`).
- Wire the contact form (`contact.html`) and newsletter forms to a backend or form service (e.g. Formspree, a serverless function, or the Woreda's own mail server).
- Add real photography to `/images` and update the gallery, news, and hero sections.
- Update `<meta property="og:image">` and canonical URLs once the production domain is assigned.

## Browser support

Modern evergreen browsers (Chrome, Firefox, Safari, Edge). Layout uses CSS Grid and Flexbox with graceful fallbacks; JavaScript features (`IntersectionObserver`) degrade gracefully if unsupported.
